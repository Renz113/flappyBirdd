import pygame
import random
import asyncio

pygame.init()

# ======================
# GAME SETTINGS
# ======================

GAME_WIDTH = 360
GAME_HEIGHT = 640

window = pygame.display.set_mode(
    (GAME_WIDTH, GAME_HEIGHT),
    pygame.SCALED
)

pygame.display.set_caption("Flappy Bird")

clock = pygame.time.Clock()

# ======================
# BIRD
# ======================

bird_width = 34
bird_height = 24

bird_x = GAME_WIDTH // 8
bird_y = GAME_HEIGHT // 2

bird = pygame.Rect(
    bird_x,
    bird_y,
    bird_width,
    bird_height
)

velocity_y = 0
gravity = 0.4

# ======================
# PIPES
# ======================

pipe_width = 64
pipe_height = 512

pipes = []

velocity_x = -3

pipe_delay = 1500
last_pipe_time = 0

# ======================
# SCORE
# ======================

score = 0
game_over = False

# ======================
# LOAD IMAGES
# ======================

background_image = pygame.image.load(
    "flappybirdbg.png"
)

bird_image = pygame.image.load(
    "flappybird.png"
)

bird_image = pygame.transform.scale(
    bird_image,
    (bird_width, bird_height)
)

top_pipe_image = pygame.image.load(
    "toppipe.png"
)

top_pipe_image = pygame.transform.scale(
    top_pipe_image,
    (pipe_width, pipe_height)
)

bottom_pipe_image = pygame.image.load(
    "bottompipe.png"
)

bottom_pipe_image = pygame.transform.scale(
    bottom_pipe_image,
    (pipe_width, pipe_height)
)

# ======================
# CREATE PIPE
# ======================


def create_pipes():

    random_pipe_y = (
        -pipe_height // 4
        - random.random() * (pipe_height // 2)
    )

    opening_space = GAME_HEIGHT // 4

    top_pipe = pygame.Rect(
        GAME_WIDTH,
        random_pipe_y,
        pipe_width,
        pipe_height
    )

    bottom_pipe = pygame.Rect(
        GAME_WIDTH,
        random_pipe_y + pipe_height + opening_space,
        pipe_width,
        pipe_height
    )

    pipes.append(("top", top_pipe))
    pipes.append(("bottom", bottom_pipe))

# ======================
# DRAW
# ======================


def draw():

    window.blit(background_image, (0, 0))

    window.blit(
        bird_image,
        (bird.x, bird.y)
    )

    for pipe_type, pipe in pipes:

        if pipe_type == "top":
            window.blit(top_pipe_image, pipe)

        else:
            window.blit(bottom_pipe_image, pipe)

    text_font = pygame.font.SysFont(
        "Comic Sans MS",
        40
    )

    text = str(int(score))

    if game_over:
        text = "Game Over"

    text_render = text_font.render(
        text,
        True,
        "white"
    )

    window.blit(text_render, (10, 10))

# ======================
# MOVE
# ======================


def move():

    global velocity_y
    global game_over
    global score

    velocity_y += gravity

    bird.y += velocity_y

    if bird.y < 0:
        bird.y = 0

    if bird.y > GAME_HEIGHT:
        game_over = True

    for pipe_type, pipe in pipes:

        pipe.x += velocity_x

        if bird.colliderect(pipe):
            game_over = True

        if pipe.x + pipe_width == bird.x:
            score += 0.5

# ======================
# MAIN LOOP
# ======================


async def main():

    global velocity_y
    global game_over
    global score
    global last_pipe_time

    running = True

    while running:

        now = pygame.time.get_ticks()

        if (
            now - last_pipe_time >= pipe_delay
            and not game_over
        ):

            create_pipes()

            last_pipe_time = now

        for event in pygame.event.get():

            if event.type == pygame.QUIT:

                running = False

            if event.type in (
                pygame.KEYDOWN,
                pygame.MOUSEBUTTONDOWN
            ):

                velocity_y = -6

                if game_over:

                    bird.y = bird_y

                    pipes.clear()

                    score = 0

                    game_over = False

        if not game_over:
            move()

        draw()

        pygame.display.flip()

        clock.tick(60)

        await asyncio.sleep(0)

    pygame.quit()

asyncio.run(main())
